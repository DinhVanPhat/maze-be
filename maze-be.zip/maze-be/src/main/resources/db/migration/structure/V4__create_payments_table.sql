-- 4. Bảng payments (Phương thức thanh toán)
CREATE TABLE payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name_payment NVARCHAR(50) NOT NULL
);