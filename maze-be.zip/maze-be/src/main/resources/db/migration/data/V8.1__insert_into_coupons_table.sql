-- Thêm mã giảm giá
INSERT INTO coupons (code, discount, min_order_value, max_uses, expires_at) 
VALUES ('SALE50', 50000, 500000, 100, '2025-12-31');