INSERT INTO payments (name_payment) VALUES
    ('cod'),
    ('momo'),
    ('vnpay'),
    ('bank_transfer');