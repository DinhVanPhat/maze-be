-- Đánh giá sản phẩm
INSERT INTO reviews (product_id, accounts_id, rating, comment) 
VALUES (1, 1, 5, 'Sản phẩm rất tốt!'),
       (2, 1, 4, 'Máy chạy mượt, rất đáng tiền!');