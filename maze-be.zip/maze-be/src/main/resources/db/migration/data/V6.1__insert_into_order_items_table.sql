-- Chi tiết đơn hàng
INSERT INTO order_items (order_id, product_id, quantity, price) 
VALUES 
        (1, 1, 2, 30000000),
        (2, 2, 1, 28000000),
        (3, 3, 3, 15000000),
        (4, 4, 2, 7500000),
        (5, 5, 1, 27000000);