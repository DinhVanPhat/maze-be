package com.maze.maze.dto.account;

import lombok.Data;

@Data
public class TokenRequest {
    private String tokenId;
}
