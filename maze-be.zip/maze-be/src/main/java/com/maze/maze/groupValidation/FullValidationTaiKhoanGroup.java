package com.maze.maze.groupValidation;

public interface FullValidationTaiKhoanGroup extends DangNhapGroup{

}
