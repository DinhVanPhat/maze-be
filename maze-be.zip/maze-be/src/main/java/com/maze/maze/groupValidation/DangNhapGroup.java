package com.maze.maze.groupValidation;

public interface DangNhapGroup {

}
